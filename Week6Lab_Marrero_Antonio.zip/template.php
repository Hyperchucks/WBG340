<!DOCTYPE html>
<html>
<head>
<title>My Gaming Products Site</title>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>

	<?php include('includes/header.inc'); ?>

	<?php include('includes/nav.inc'); ?>

<div id="wrapper">


	

	<?php include('includes/aside.inc'); ?>
	<section>
	<p>Main content goes here...</p>
	<p>Main content goes here...</p>
	<p>Main content goes here...</p>
	<p>Main content goes here...</p>
	<p>Main content goes here...</p>

	</section>

</div>

	<?php include('includes/footer.inc'); ?>

</body>
</html>
