<?php
include('includes/dbc_admin.php');

$product_id = isset($_GET['id'])?$_GET['id']:-1;
$msg = "";
if($product_id == -1)
{
    //add review.
    $product_id = isset($_POST['id'])?$_POST['id']:-1;
    $name = isset($_POST['name'])?$_POST['name']:"";
    $comment = isset($_POST['comment'])?$_POST['comment']:"";

    $query = "insert into reviews(product_id, name, comment, review_date) values ($product_id,'$name','$comment',now())";
    $result = mysqli_query($con, $query); // $con from dbc.php
    if($result)
    {
        $msg = "Success! Thank your for your review!";
    }


}

?>

<!DOCTYPE html>
<html>
<head>
<title>My Gaming Products Site</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<script src="jquery.js"></script>
<script>
    $(function(){
        $("#Submit").click(function(){
            if($("#name").val()=="")
            {
                alert("Please enter the name!");
                $("#name").focus();
                return;
            }
            if($("#comment").val()=="")
            {
                alert("Please enter the comment!");
                $("#comment").focus();
                return;
            }
            $("#addreviewform").submit();
        });
    })
</script>
</head>

<body>

	<?php include('includes/header.inc'); ?>

	<?php include('includes/nav.inc'); ?>

<div id="wrapper">


	

	<?php include('includes/aside.inc'); ?>
	<section>
        <?php
        if($msg == "")
        {
            ?>
            <h2>Add Review</h2>
            <form id="addreviewform" name="addreviewform" method="post" action="add_review.php">
                <p>Name:
                    <br>
                    <input type="text" name="name" id="name">
                    <input type="hidden" value="<?php echo $product_id;?>" name="id" id="product_id"/>
                </p>
                <p>Comment:
                    <br>
                    <textarea id="comment" name="comment"></textarea>
                </p>
                <p><input type="button" id="Submit" value="Submit" ></p>
            </form><br>
            <br>
            <?php
        }else
        {
            ?>
            <h2><?php echo $msg; ?></h2>
            <?php
        }
        ?>




	</section>

</div>

	<?php include('includes/footer.inc'); ?>

</body>
</html>
