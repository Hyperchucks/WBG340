<?php
//************************************************************
//		File: dbc.php
//		Connect Read-only to MySQL database via PHP
//************************************************************

	$host = "localhost";
	 $userName = "amarrero_410rdo";
	 $passWord = "ALto1013#@!";
//    $userName = "root";
//    $passWord = "";
	$dataBase = "amarrero_gameSite";
	
	$con = mysqli_connect($host, $userName, $passWord, $dataBase);
	
	$connection_error = mysqli_connect_error();
	if($connection_error != null) {
		echo "<p>Error connecting to database: $connection_error </p>";
	} else {
		/* echo "Connected to Read-only MySQL<br />"; */
	}

?>