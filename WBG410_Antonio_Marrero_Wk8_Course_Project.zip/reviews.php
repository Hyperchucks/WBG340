<?php
$product_id = isset($_GET['id'])?$_GET['id']:-1;
?>
<!DOCTYPE html>
<html>
<head>
    <title>My Gaming Products Site</title>
    <link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<?php include('includes/header.inc'); ?>

<?php include('includes/nav.inc'); ?>

<div id="wrapper">




    <?php include('includes/aside.inc'); ?>
    <section>
        <h2>Reviews</h2>
        <table width="100%">
            <tr>
                <th>Name</th>
                <th>Comment</th>
                <th>Review Date</th>

            </tr>

            <?php include('includes/dbc.php');
            $sql = "SELECT * FROM reviews where product_id = $product_id ORDER BY id ASC";

            $result = mysqli_query($con, $sql);
            if($result == false) {
                $error_message = mysqli_error($con);
                echo "<p>There has been a query error: $error_message</p>";
            } else {
                if(mysqli_num_rows($result)==0) {
                    echo '<tr><td colspan="4">There are no reviews for this product<br/><a href="add_review.php?id=$product_id">Add Review!</a></td></tr>';
                } else {
                    while($row=mysqli_fetch_assoc($result)) {
                        echo '<tr><td align="center">' .$row['name'] . '</td>';
                        echo '<td align="center">' .$row['comment'] . '</td>';
                        echo '<td align="center">' .$row['review_date'] . '</td>';
                        echo '</tr>';
                    } //end while
                } // end else
            } // end if

            ?>

        </table>

    </section>

</div>

<?php include('includes/footer.inc'); ?>

</body>
</html>
